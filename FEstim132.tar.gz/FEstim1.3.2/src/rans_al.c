/* Taken from Myrna Jewett and Elizabeth A. Thompson's MORGAN program
 *
 * SUPER-DUPER RANDOM NUMBER GERNERATOR
 *
 * ANSI C version of Marsaglia's "super-duper" random number
 * generator.
 *
 * Random number generator used in Berkeley ISP and S.
 *
 * USAGE:
 *
 *    uint32 lran(void);                  returns a random 32 bit unsigned int
 *    double rans(void);                  returns a random double uniformly
 *                                        distributed in (0,1)
 *    int intran(int low, int high);      returns random signed int x, such
 *                                        that low <= x <= high
 *    void getsd(uint32 *c, uint32 *t);   put current values of two seeds in
 *                                        c and t
 *    void setsd(uint32 c, uint32 t);     set current seeds
 *
 * DESCRIPTION:
 *
 * Two independent generators are maintained internally:
 * a linear congruential generator with multiplier 69069 and modulus 2^32;
 * and a Tausworthe generator based on primitive trinomial x^32 + x^17 + 1.
 * The two seeds are XOR'd together to give the random number.
 *
 * cseed must be odd, and tseed must be nonzero in order to obtain the
 * full period.
 *
 * The Tausworthe generator has period length 2^32 - 1, and the congruential
 * generator has period 2^30.  Because the congruential and Tausworthe
 * generators are independent and have relatively prime periods, the ultimate
 * period is (2^30) * (2^32 - 1), or about 2^62.
 *
 */

#include "rans_al.h"

static uint32 cseed = 12345u;
static uint32 tseed = 1073u;
static uint32 multiplier = 69069;

/*
 * Zero extension on the left and right shifts is guaranteed by ANSI C
 * for unsigned operands.  Unsigned multiplication is guaranteed to give
 * correct result mod 2^32 if uint32 is 32-bit type.
 */

#define UNI \
	tseed ^= (tseed >> 15); \
	tseed ^= (tseed << 17); \
	cseed *= multiplier

/* 32 bit random unsigned integer */
uint32 lran (void)
{
   UNI;
   return cseed ^ tseed;
}

/* double precision uniform (0,1) random variate */
double rans (void)
{
   register uint32 foo;
   do
   {
      UNI;
      foo = tseed ^ cseed; 
   }
   while (foo == 0);
   return ((double) foo) / 4294967296.0;
}

/* random integer between low and high (inclusive) */
int   intran (int low, int high)
{
   return low + (int) (rans () * (high + 1 - low));
}

/* set seed values */
void  setsd (uint32 c, uint32 t)
{
   /* enforce cseed odd and tseed nonzero */
   cseed = c | 1;
   tseed = t != 0 ? t : 1;
}

/* get seed values */
void  getsd (uint32 * cp, uint32 * tp)
{
   *cp = cseed;
   *tp = tseed;
}
