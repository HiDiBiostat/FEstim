/*****************************************************************/
/*    Viterbi algo for finding the most likely IBD sequence      */
/*             for 2 genes given the observed genotypes          */
/*   [January 2009]                                              */
/* Author: Anne-Louise Leutenegger                               */
/*****************************************************************/


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
 
#include "pg.h"
 
/* extern */
int TOT_NUM_LOCUS;
/* int TOT_NUM_INDIV; */
int NUM_SCALE;
/* real SCALE; */
/* markmap *MAP; */
/* indiv *DATA; */
/* vector xall;  */
/* tmaxn itp; */
/* FILE *outfile, *detfile; */
/* End extern */ 

int Viterbi(real inb, real aa, markmap *map, int **y, int *best_ibd) {
  /* Bellman-Viterbi algorithm */
  /*   Bellman RE and Dreyfus SE (1962) */
  /*     Applied Dynamic Programming. Princeton U press */
  /*   Viterbi AJ(1967) IEEE Trans Information Theory, 13: 260-269 */
  int i,s,j=999,l,l_mult=0;
  real prior,proba,trans,pnew=0.,p=0.,sum=0.,lsum1=0.;
  real **v,**jstar;

  if ((v=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
    printf("Could not allocate memory for v in Viterbi\n"); 
    return 0;
  }
  if ((jstar=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
    printf("Could not allocate memory for jstar in Viterbi\n"); 
    return 0;
  }
  /* get v & jstar going forward */
  /* Start with first locus: */
  /* NUM_SCALE=0; */
  for (s=0;s<TOT_IBD_STATE;s++) {
    if (!get_prior(s,inb,&prior)) {
      printf("Problem in Viterbi for get_prior at pos 0\n"); 
      return 0;
    }
    if(!get_proba(y[0],s,map[0].freq,&proba)) {
      printf("Problem in Viterbi for get_proba at pos 0\n"); 
      return 0;
    }
    v[0][s]=proba*prior;
/*     sum+=v[0][s]; */
  }
/*   for (s=0;s<TOT_IBD_STATE;s++) { */
/*     v[0][s]/=(real)sum; //P(I_0|Y_0) normalized */
/*   } */
  /* Then loci 1 to L: */
  l_mult=0;
  for (l=1;l<TOT_NUM_LOCUS;l++) {
    lsum1+=log(sum);
/*     if(sum1 > 0 && sum1 < 10E-20) {sum1*=SCALE; NUM_SCALE++;} */
    sum=0;
    for (s=0;s<TOT_IBD_STATE;s++) {
      if (!get_proba(y[l],s,map[l].freq,&proba)) { 
	printf("Problem in Viterbi for get_proba\n"); 
	return 0; 
      }
/*       if (map[l].dist==0.0 && map[l-1].dist != 0.0) { */
      if (map[l].chr != map[l-1].chr) {
	if (!get_prior(s,inb,&trans)) { 
	  printf("Problem in Viterbi for prior at pos=%d, IBD state=%d\n",l,s); 
	  return 0; 
	}
	p=trans;
	j=999; /* There is no previous locus */
      } else {
	p=0; pnew=0;
	for (i=0;i<TOT_IBD_STATE;i++) {
	  if (!get_trans(i,s,inb,aa,map[l].dist-map[l-1].dist,&trans)) { 
	    printf("Problem in Viterbi for get_trans\n"); 
	    return 0; 
	  }
	  pnew=trans*v[l-1][i];
	  if (pnew > p) {
	    p=pnew; j=i;
	  }
	}
      }
/*       qstar[l][s]=p; */
/*       if (p==0.) {qstar[l][s]=10E-20; } */
/*       else {qstar[l][s]=p;}  */
/*       if (l==l_mult) { p=p*SCALE; } */
/*       if (p > 0 && p < 10E-20) {        */
/* 	l_mult=l; l--; NUM_SCALE++; // printf("%d ",NUM_SCALE); break;  */
/*       } */
      v[l][s]=p*proba;
      jstar[l][s]=j;
/*       sum+=v[l][s]; */
      
    }
/*     for (s=0;s<TOT_IBD_STATE;s++) { */
/*       v[l][s]/=(real)sum; //P(I_l|Y_0...Y_l) normalized */
/*       if (l==TOT_NUM_LOCUS-1) { */
/* 	q[l][s]=v[l][s]; //Last locus P(I_L|Y_all) */
/*       } */
/*     } */
/*     if (l==TOT_NUM_LOCUS-1) { */
/*       printf("Py=%Lf , lnPy(corrected)=%Lf\n",sum*exp(lsum1)/pow(SCALE,NUM_SCALE),(real)(log(sum)+lsum1-(NUM_SCALE*log(SCALE)))); */
/*     } */
  }
  /* best_ibd at L=TOT_NUM_LOCUS-1 */
  best_ibd[TOT_NUM_LOCUS-1]=0;
  for (s=1;s<TOT_IBD_STATE;s++) {
    if (v[TOT_NUM_LOCUS-1][s] > v[TOT_NUM_LOCUS-1][s-1]) {
      best_ibd[TOT_NUM_LOCUS-1]=s;
    }
  }
  
  /* get best_ibd from L-1 to 0, going backward */
  for (l=TOT_NUM_LOCUS-1;l>0;l--) {
    if (map[l].chr != map[l-1].chr) {
      best_ibd[l-1]=0;
      for (s=1;s<TOT_IBD_STATE;s++) {
	if (v[l-1][s] > v[l-1][s-1]) {
	  best_ibd[l-1]=s;
	}
      }
    } else {
      best_ibd[l-1]=jstar[l][best_ibd[l]];
    }
  }

  Free2Ddouble(jstar);
  Free2Ddouble(v);

  return 1;
}

int Viterbi2(real inb, real aa, markmap *map, int **y, int *best_ibd) {
  /* As I understand it from Bernard Prum's explanation  */
  /* WRONG */
  int i,s,j=999,l,l_mult=0;
  real trans,pnew=0.,p=0.,sum=0.,lsum1=0.;
  real **v,**jstar,**q,***qq;

  if ((v=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
    printf("Could not allocate memory for v in Viterbi2\n"); 
    return 0;
  }
  if ((jstar=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
    printf("Could not allocate memory for jstar in Viterbi2\n"); 
    return 0;
  }
  if ((q=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
    printf("Could not allocate memory for q in Viterbi2\n"); 
    return 0;
  }
  if ((qq=Init3Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,TOT_IBD_STATE,0))==NULL) { 
    printf("Could not allocate memory for qq in Viterbi2\n"); 
    return 0;
  }

  if(!Conditional_proba(inb,aa,map,y,TOT_NUM_LOCUS,q,qq)) {
    printf("Problem in Viterbi2 for Conditional_proba\n"); 
    return 0;
  }

  /* get v & jstar going forward */
  /* Start with first locus: */
  /* NUM_SCALE=0; */
  for (s=0;s<TOT_IBD_STATE;s++) {
    v[0][s]=q[0][s];
  }
  l_mult=0;
  for (l=1;l<TOT_NUM_LOCUS;l++) {
    lsum1+=log(sum);
/*     if(sum1 > 0 && sum1 < 10E-20) {sum1*=SCALE; NUM_SCALE++;} */
    sum=0;
    for (s=0;s<TOT_IBD_STATE;s++) {
/*       if (!get_proba(y[l],s,map[l].freq,&proba)) {  */
/* 	printf("Problem in Viterbi2 for get_proba\n");  */
/* 	return 0;  */
/*       } */
/*       if (map[l].dist==0.0 && map[l-1].dist != 0.0) { */
      if (map[l].chr != map[l-1].chr) {
	if (!get_prior(s,inb,&trans)) { 
	  printf("Problem in Viterbi2 for prior at pos=%d, IBD state=%d\n",l,s); 
	  return 0; 
	}
	p=trans;
	j=999; /* There is no previous locus */
      } else {
	p=0; pnew=0;
	for (i=0;i<TOT_IBD_STATE;i++) {
	  if (!get_trans(i,s,inb,aa,map[l].dist-map[l-1].dist,&trans)) { 
	    printf("Problem in Viterbi2 for get_trans\n"); 
	    return 0; 
	  }
	  pnew=trans*v[l-1][i];
	  if (pnew > p) {
	    p=pnew; j=i;
	  }
	}
      }
      v[l][s]=p*q[l][s];
      jstar[l][s]=j;
      
    }
  }
  /* best_ibd at L=TOT_NUM_LOCUS-1 */
  best_ibd[TOT_NUM_LOCUS-1]=0;
  for (s=1;s<TOT_IBD_STATE;s++) {
    if (v[TOT_NUM_LOCUS-1][s] > v[TOT_NUM_LOCUS-1][s-1]) {
      best_ibd[TOT_NUM_LOCUS-1]=s;
    }
  }
  
  /* get best_ibd from L-1 to 0, going backward */
  for (l=TOT_NUM_LOCUS-1;l>0;l--) {
    if (map[l].chr != map[l-1].chr) {
      best_ibd[l-1]=0;
      for (s=1;s<TOT_IBD_STATE;s++) {
	if (v[l-1][s] > v[l-1][s-1]) {
	  best_ibd[l-1]=s;
	}
      }
    } else {
      best_ibd[l-1]=jstar[l][best_ibd[l]];
    }
  }

  Free2Ddouble(jstar);
  Free2Ddouble(v);
  Free2Ddouble(q);
  Free3Ddouble(qq,TOT_NUM_LOCUS);

  return 1;
}

