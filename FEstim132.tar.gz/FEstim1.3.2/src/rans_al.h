
/*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
/*                rans.h:  header file for Rans/                        */
/*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/


/* Definition of uint32 (32 bit unsigned integer type) moved to globs.h */

/* ALL//#include "incs.h" */
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include <stddef.h>
#include <time.h>
#include <unistd.h>

#define CONGRUENTIAL_SEED 12345u        /* default seed values          */
#define TAUSWORTHE_SEED   1073u         /* (see rans.c)                 */

/* Define uint32 to be a 32 bit unsigned integer type                   */ 
/* (used by Rans/ and Pars/ functions                                   */
/* If there isn't one, the code would have to be rewritten              */
/* to emulate 32 bit arithmetic.                                        */
typedef unsigned int uint32;           /*this works on RISC workstations*/

/*ALL //enum {MARK, TRAIT, SAMPL};        // seed types for mSeeds.c    */

double rans(void);
/* ALL//double normal(double, double); */
int intran(int, int);
void setsd(uint32, uint32);
void getsd(uint32 *, uint32 *);
/* ALL//void get_seeds(const char *fname); */
/* ALL//void put_seeds(const char *fname); */
/* ALL//int rand_int(double *work, int k ); */
/* ALL//void permute(int *ab, int n); */

/* ALL//void setSeeds(int); */
/* ALL//void getSeeds(int); */
/* ALL//void assgnSeeds(void); */
/* ALL//void writSeeds(FILE *); */
