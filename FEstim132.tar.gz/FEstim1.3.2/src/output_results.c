/***************************************************/
/*        Print out the output files               */
/*                                     [July 2006] */
/*                                                 */
/* Name: output_results.c                          */
/* Anne-Louise Leutenegger                         */
/***************************************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "pg.h"

/* extern */
int TOT_NUM_LOCUS;
int TOT_NUM_INDIV;
int NUM_SCALE;
markmap *MAP;
indiv *DATA;
vector xall; 
tmaxn itp;
FILE *outfile, *detfile;
/* End extern */ 

int Print_inbreeding(char *filename, char *std_error, int nindiv, 
		     real inb, real a, real *se) {
  FILE *INB_OUT;

  if (nindiv==0) {
    if ((INB_OUT=fopen(filename,"w"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
    /* MCB : added tabs as delimiters */
    fprintf(INB_OUT,"%-40s\t%5s\t%5s\t%5s\t%5s\n",
	    " Individual", "F", "StdE", "A", "StdE");
  } else {
    if ((INB_OUT=fopen(filename,"a"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
  }
  /* MCB : added tabs as delimiters */
  if (DATAisZERO[nIndiv]<TOT_NUM_LOCUS) {
    if (strcmp(std_error,"SE")==0 && inb > 1.0E-8) {
      fprintf(INB_OUT,"%19s_%-20s\t%5.3f\t%5.3f\t%5.3f\t%5.3f\n",
	      DATA[nindiv].famid,DATA[nindiv].id,inb,se[0],a,se[1]);
    } else {
      fprintf(INB_OUT,"%19s_%-20s\t%5.3f\t%5s\t%5.3f\t%5s\n",
	      DATA[nindiv].famid,DATA[nindiv].id,inb,"NA",a,"NA");
    }
  } else {
    fprintf(INB_OUT,"%19s_%-20s\t%5s\t%5s\t%5s\t%5s\n",
	    DATA[nindiv].famid,DATA[nindiv].id,"NA","NA","NA","NA");
  }

  fclose (INB_OUT);
  return 1;
}

int Print_inbreeding_nuclear(char *filename, int *indiv_aff, 
		     real *inb_med, real *a_med) {
  /* Print Median F and A when "nuclear" lodscore is used*/
  FILE *INB_OUT;
  int fam;

  if ((INB_OUT=fopen(filename,"a"))==NULL) {
    Eprintf("\nERROR: File %s could not be opened\n",filename);
    return 0;
  }
  /* MCB : added tabs as delimiters*/
  for (fam=0;fam<TOT_NUM_FAM;fam++) {
    fprintf(INB_OUT,"%19s_%-20s\t%5.3f\t%5s\t%5.3f\t%5s\n",
	    DATA[(indiv_aff[fam])].famid,"medians",inb_med[fam],
	    "NA",a_med[fam],"NA");
  }

  fclose (INB_OUT);
  return 1;
}

int Print_lodscore(char *filename, real *lod) {
  /* Print out lodscore logTk */
  /* If "independent": sum logTkn from each individual */
  /* If "nuclear": only logTk for the 1st affected individual */
  /*               in family + user provided LODnoInbreeding  */
  FILE *LOD_OUT;
  int l;

  if ((LOD_OUT=fopen(filename,"w"))==NULL) {
    Eprintf("\nERROR: File %s could not be opened\n",filename);
    return 0;
  }
  /* MCB : added MarkerName and tabs as delimiters */
  fprintf(LOD_OUT,"%10s\t%3s\t%7s\t%8s\n","locus","chr","pos","FLOD");
  for (l=0;l<TOT_NUM_LOCUS;l++) {
    if (lod[l] == mINF) {
      fprintf(LOD_OUT,"%10s\t%3d\t%7.3f\t%8.0f\n",
	      MAP[l].name,MAP[l].chr,MAP[l].dist,mINF);
    } else {
      fprintf(LOD_OUT,"%10s\t%3d\t%7.3f\t%8.3f\n",
	      MAP[l].name,MAP[l].chr,MAP[l].dist,lod[l]);
    }
  }  

  fclose (LOD_OUT);
  return 1;
}

int SumNprint_family_lod(char *filename, real **fam_lod_noinbreed, 
			 int add, int first_print, int fam, int nindiv, 
			 real *lodn) {
  FILE *FAMLOD_OUT;
  int l;

  if (first_print==0) {
    if ((FAMLOD_OUT=fopen(filename,"w"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
    fprintf(FAMLOD_OUT,"%10s\t%10s\t%3s\t%7s\t%8s\n",
	    "family","locus","chr","pos","FLOD");
  } else {
    if ((FAMLOD_OUT=fopen(filename,"a"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
  }
  for (l=0;l<TOT_NUM_LOCUS;l++) {
    if (add==1) {
      if (fam_lod_noinbreed[fam][l]==mINF || lodn[l]==mINF) {
	lodn[l]=mINF;
      } else {
	lodn[l]+=fam_lod_noinbreed[fam][l];
      }
    }
    if (lodn[l] == mINF) {
      fprintf(FAMLOD_OUT,"%10s\t%10s\t%3d\t%7.3f\t%8.0f\n",
	      DATA[nindiv].famid,MAP[l].name,MAP[l].chr,MAP[l].dist,mINF);
    } else {
      fprintf(FAMLOD_OUT,"%10s\t%10s\t%3d\t%7.3f\t%8.3f\n",
	      DATA[nindiv].famid,MAP[l].name,MAP[l].chr,MAP[l].dist,lodn[l]);
    }
  }

  fclose (FAMLOD_OUT);
/*   if (nindiv==TOT_NUM_INDIV-1) { */
/*     fclose (FAMLOD_OUT); */
/*   } */
  return 1;
}

int SumNprint_family_lod_independent(char *filename, real *lodn, 
				     int nindiv, real *lod) {
  FILE *FAMLOD_OUT;
  int l;

  if (nindiv==0) {
    if ((FAMLOD_OUT=fopen(filename,"w"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
    fprintf(FAMLOD_OUT,
	    "%10s\t%10s\t%3s\t%7s\t%8s\n",
	    "family","locus","chr","pos","FLOD");
  } else {
    if ((FAMLOD_OUT=fopen(filename,"a"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
  }
  for (l=0;l<TOT_NUM_LOCUS;l++) {
    if (lodn[l]==mINF || lod[l]==mINF) {
      lod[l]=mINF;
    } else {
      lod[l]+=lodn[l];
    }      
    if (lodn[l] == mINF) {
      fprintf(FAMLOD_OUT,"%10s\t%10s\t%3d\t%7.3f\t%8.0f\n",
	      DATA[nindiv].famid,MAP[l].name,MAP[l].chr,MAP[l].dist,
	      mINF);
    } else {
      fprintf(FAMLOD_OUT,"%10s\t%10s\t%3d\t%7.3f\t%8.3f\n",
	      DATA[nindiv].famid,MAP[l].name,MAP[l].chr,MAP[l].dist,
	      lodn[l]);
    }
  }

  fclose (FAMLOD_OUT);
  return 1;
}

int Print_conditional_proba(char *filename, int first_print, int nindiv, 
			    real inb, real a, real **q, real *lodn) {
  FILE *CPROBA_OUT;
  int l;

  if (first_print==0) {
    if ((CPROBA_OUT=fopen(filename,"w"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
  } else {
    if ((CPROBA_OUT=fopen(filename,"a"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
  }
  fprintf(CPROBA_OUT,"#Individual %6s_%-6s\n",
	  DATA[nindiv].famid,DATA[nindiv].id);
  fprintf(CPROBA_OUT,"#F=%5.3f, A=%5.3f\n",inb,a);
  fprintf(CPROBA_OUT,"%3s %7s %8s %8s %8s %7s%1s %8s\n",
	  "chr", "pos", "IBD0", "IBD1", "Sum","genoty","pe","FLOD");

  for (l=0;l<TOT_NUM_LOCUS;l++) {
    if (lodn[l] == mINF) {
      fprintf(CPROBA_OUT,"%3d %7.3f %8.6f %8.6f %8.6f %7d,%1d %8.0f\n",
	      MAP[l].chr,MAP[l].dist,q[l][0],q[l][1],q[l][1]+q[l][0],
	      DATA[nindiv].markdat[l][0],DATA[nindiv].markdat[l][1],mINF);
    } else {
      fprintf(CPROBA_OUT,"%3d %7.3f %8.6f %8.6f %8.6f %7d,%1d %8.3f\n",
	      MAP[l].chr,MAP[l].dist,q[l][0],q[l][1],q[l][1]+q[l][0],
	      DATA[nindiv].markdat[l][0],DATA[nindiv].markdat[l][1],lodn[l]);
    }
  }

  fclose (CPROBA_OUT);
  return 1;
}

int Print_conditional_proba_v2(char *filename, int first_print, int nindiv, 
			       real **q, real *lodn, int *BI) {
  FILE *CPROBA_OUT;
  int l;

  if (first_print==0) {
    if ((CPROBA_OUT=fopen(filename,"w"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
    fprintf(CPROBA_OUT,"%11s %7s %3s %7s %7s%1s %8s %8s %7s\n",
	    "Individual", "marker", "chr", "pos", "genoty","pe", 
	    "PIBD1", "FLOD", "BestIBD");
  } else {
    if ((CPROBA_OUT=fopen(filename,"a"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
  }

  for (l=0;l<TOT_NUM_LOCUS;l++) {
    if (lodn[l] == mINF) {
      fprintf(CPROBA_OUT,
	      "%5s_%-5s %7s %3d %7.3f %7d,%1d %8.6f %8.0f %7d\n",
	      DATA[nindiv].famid,DATA[nindiv].id,
	      MAP[l].name,MAP[l].chr,MAP[l].dist,
	      DATA[nindiv].markdat[l][0],DATA[nindiv].markdat[l][1],
	      q[l][1],mINF,BI[l]);
    } else {
      fprintf(CPROBA_OUT,
	      "%5s_%-5s %7s %3d %7.3f %7d,%1d %8.6f %8.3f %7d\n",
	      DATA[nindiv].famid,DATA[nindiv].id,
	      MAP[l].name,MAP[l].chr,MAP[l].dist,
	      DATA[nindiv].markdat[l][0],DATA[nindiv].markdat[l][1],
	      q[l][1],lodn[l],BI[l]);
    }
  }

  fclose (CPROBA_OUT);
  return 1;
}

int Print_bestibd(char *filename, int first_print, int nindiv, 
			    real inb, real a, int *BI) {
  FILE *BI_OUT;
  int l;

  if (first_print==0) {
    if ((BI_OUT=fopen(filename,"w"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
  } else {
    if ((BI_OUT=fopen(filename,"a"))==NULL) {
      Eprintf("\nERROR: File %s could not be opened\n",filename);
      return 0;
    }
  }
  fprintf(BI_OUT,"#Individual %6s_%-6s\n",
	  DATA[nindiv].famid,DATA[nindiv].id);
  fprintf(BI_OUT,"#F=%5.3f, A=%5.3f\n",inb,a);
  fprintf(BI_OUT,"%3s %7s %7s%1s %7s\n",
	  "chr", "pos", "genoty","pe","BestIBD");

  for (l=0;l<TOT_NUM_LOCUS;l++) {
    fprintf(BI_OUT,"%3d %7.3f %7d,%1d %7d\n",
	    MAP[l].chr,MAP[l].dist,
	    DATA[nindiv].markdat[l][0],DATA[nindiv].markdat[l][1],BI[l]);
  }

  fclose (BI_OUT);
  return 1;
}
