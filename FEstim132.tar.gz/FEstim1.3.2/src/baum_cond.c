/*****************************************************************/
/*    Baum algo for likelihood & IBD dsn conditional on data     */
/*                     for 2 genes                               */
/*                                                     [Apr 2002]*/
/* Author: Anne-Louise Leutenegger                               */
/* Name: baum_cond.c                                             */
/*****************************************************************/


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
 
#include "pg.h"
#include "rans_al.h" /* for Sample_from_posterior1() */
 
/* extern */
/* int TOT_NUM_LOCUS; */
/* int TOT_NUM_INDIV; */
int NUM_SCALE;
/* markmap *MAP; */
/* indiv *DATA; */
/* markmap *CMAP; */
/* indiv *CDATA; */
/* int CSOME_NUM_LOCUS; */
/* vector xall;  */
/* tmaxn itp; */
/* FILE *outfile, *detfile; */
/* int COMPUT_CSOME; */
/* End extern */ 

int Likfast(real inb, real aa, markmap *map, int **y, int nmarker, real *proba_data) {
  /* LogLikelihood -- Forward Baum algorithm */
  int i;
  real proba, p=0;
  real **rstar;

  if ((rstar=Init2Ddouble(nmarker,TOT_IBD_STATE+1,0))==NULL) { 
    Eprintf("Could not allocate memory for rstar in Likfast\n"); 
    return 0;
  }
  if(!Forward(inb,aa,map,y,nmarker,rstar)) {
    Eprintf("Problem with Forward in Likfast\n"); 
    return 0;
  }
  for (i=0;i<TOT_IBD_STATE;i++) {
    if(!get_proba(y[nmarker-1],i,map[nmarker-1].freq,&proba)) {
      Eprintf("Problem in get_proba from Likfast\n");  
      return 0; 
    } 
    p+=proba*rstar[nmarker-1][i]; 
  }

  if (p > 0.) {  
    *proba_data=(real)(log(p)-(NUM_SCALE*log(SCALE)));
  }  else {
    *proba_data=(real)mINF;
  }

  Free2Ddouble(rstar);
  return 1;
}

int Forward(real inb, real aa, markmap *map, int **y, int nmarker, real **RStar) {
  real prior,trans,proba,sum=0;
  real p=0;
  int s,i,l,l_mult;

  NUM_SCALE=0;
  for (s=0;s<TOT_IBD_STATE;s++) {
    if (!get_prior(s,inb,&prior)) {Eprintf("Problem in Forward at pos 0\n"); return 0;}
    RStar[0][s]=prior;
    sum+=RStar[0][s];
  }
  RStar[0][TOT_IBD_STATE]=sum;
  l_mult=0;
  for (l=1;l<nmarker;l++) {

    sum=0;
    for (s=0;s<TOT_IBD_STATE;s++) {
/*       if (map[l].dist==0.0 && map[l-1].dist != 0.0) { */
      if (map[l].chr != map[l-1].chr) {
	if (!get_prior(s,inb,&trans)) { 
	  Eprintf("Problem in Forward at pos=%d, IBD state=%d\n",l,s); 
	  return 0; 
	}
      }
      p=0;
      for (i=0;i<TOT_IBD_STATE;i++) {
/* 	if (map[l].dist==0.0 && map[l-1].dist != 0.0) { */
	if (map[l].chr != map[l-1].chr) {
	  if (!get_proba(y[l-1],i,map[l-1].freq,&proba)) { 
	    Eprintf("Problem in Forward at pos=%d, IBD state=%d\n",l,s); 
	    return 0; 
	  }
	}
	else {
	  if (!(get_trans(i,s,inb,aa,map[l].dist-map[l-1].dist,&trans) 
		&& get_proba(y[l-1],i,map[l-1].freq,&proba))) { 
	    Eprintf("Problem in Forward at pos=%d, IBD state=%d\n",l,s); 
	    return 0; 
	  }
	}
	p+=trans*proba*RStar[l-1][i];
      }
      if (l==l_mult) { p=p*SCALE;}
      if (p > 0 && p < 10E-20) { l_mult=l; NUM_SCALE++; l--; break; }
      sum+=p;
      RStar[l][s]=p;
    }
    if (l_mult<=l) {RStar[l][TOT_IBD_STATE]=sum;}
  }

  return 1;
}

int Conditional_proba(real inb, real aa, markmap *map, int **y, int nmarker, real **q, real ***qq) {
  /* Forward & Backward Baum algorithm */
  int i,s,l;
  real prior,proba,trans,p=0.,sum=0.,lsum1=0.;
  real **qstar,**qcross;
  real testsum;

  if ((qstar=Init2Ddouble(nmarker,TOT_IBD_STATE,0))==NULL) { 
    Eprintf("Could not allocate memory for qstar in Conditional_proba\n"); 
    return 0;
  }
  if ((qcross=Init2Ddouble(nmarker,TOT_IBD_STATE,0))==NULL) { 
    Eprintf("Could not allocate memory for qcross in Conditional_proba\n"); 
    return 0;
  }
  /* get qstar & qcross going FORWARD */
  /* Start with first locus: */
  for (s=0;s<TOT_IBD_STATE;s++) {
    if (!get_prior(s,inb,&prior)) {
      Eprintf("Problem in Conditional_proba for get_prior at pos 0\n"); 
      return 0;
    }
    if(!get_proba(y[0],s,map[0].freq,&proba)) {
      Eprintf("Problem in Conditional_proba for get_proba at pos 0\n"); 
      return 0;
    }
    qcross[0][s]=proba*prior;
    qstar[0][s]=prior;
    sum+=qcross[0][s];
  }
  testsum=0;
  for (s=0;s<TOT_IBD_STATE-1;s++) {
    qcross[0][s]/=(real)sum; /* P(I_0|Y_0) normalized */
    testsum+=qcross[0][s];
  }
  qcross[0][TOT_IBD_STATE-1]=1.-testsum;/* P(I_0|Y_0) normalized for TOT_IBD_STATE-1 */
  /* Then loci 1 to L: */
  for (l=1;l<nmarker;l++) {
    lsum1+=log(sum);
    sum=0;
    for (s=0;s<TOT_IBD_STATE;s++) {
      if (!get_proba(y[l],s,map[l].freq,&proba)) { 
	Eprintf("Problem in Conditional_proba for get_proba\n"); 
	return 0; 
      }
/*       if (map[l].dist==0.0 && map[l-1].dist != 0.0) { */
      if (map[l].chr != map[l-1].chr) {
	if (!get_prior(s,inb,&trans)) { 
	  Eprintf("Problem in Conditional_proba for prior at pos=%d, IBD state=%d\n",l,s); 
	  return 0; 
	}
	p=trans;
      } else {
	p=0;
	for (i=0;i<TOT_IBD_STATE;i++) {
	  if (!get_trans(i,s,inb,aa,map[l].dist-map[l-1].dist,&trans)) { 
	    Eprintf("Problem in Conditional_proba for get_trans\n"); 
	    return 0; 
	  }
	  p+=trans*qcross[l-1][i];
	}
      }
      qstar[l][s]=p;
      qcross[l][s]=p*proba;
      sum+=qcross[l][s];
      
    }
    testsum=0;
    for (s=0;s<TOT_IBD_STATE-1;s++) {
      qcross[l][s]/=(real)sum; /* P(I_l|Y_0...Y_l) normalized */
      testsum+=qcross[l][s];
      if (l==nmarker-1) {
	q[l][s]=qcross[l][s]; /* Last locus P(I_L|Y_all) */
      }
      qcross[l][TOT_IBD_STATE-1]=1.-testsum; /* P(I_l|Y_0...Y_l) normalized */
      if (l==nmarker-1) {
	q[l][TOT_IBD_STATE-1]=qcross[l][TOT_IBD_STATE-1]; /* Last locus P(I_L|Y_all) */
      }
    }
  }
  
  /* get q going BACKWARD */
  /* Then loci L-1 to 0: */
  for (l=nmarker-1;l>0;l--) {
    for (s=0;s<TOT_IBD_STATE;s++) {
/*       if (map[l].dist==0.0 && map[l-1].dist != 0.0) { */
      if (map[l].chr != map[l-1].chr) {
	q[l-1][s]=qcross[l-1][s];
	for (i=0;i<TOT_IBD_STATE;i++) {
	  qq[l][s][i]=qcross[l-1][s]*q[l][i];
	}
      } else {	
	p=0;
	for (i=0;i<TOT_IBD_STATE;i++) {
	  if (!get_trans(s,i,inb,aa,map[l].dist-map[l-1].dist,&trans)) {
	    Eprintf("Problem in get_trans from Conditional_proba\n"); 
	    return 0;
	  }
	  if(qstar[l][i]==0) {
	    Eprintf("\nError in Conditional_proba: qstar[%d][%d]=0, division by zero\n",l,i); 
	    return 0;
	  }
	  p+=trans*q[l][i]/(real)qstar[l][i];
	  qq[l][s][i]=qcross[l-1][s]*trans*q[l][i]/(real)qstar[l][i]; 
	}
	q[l-1][s]=qcross[l-1][s]*p;
      }
    }
  }

  /* Finally, taking care of QQ[0] which is supposed to be P(I_{-1} I_0 |Y_all) */
  for (s=0; s<TOT_IBD_STATE;s++) {
    for (i=0;i<TOT_IBD_STATE;i++) {
      qq[0][i][s]=q[0][s];
    }
  }

  Free2Ddouble(qstar);
  Free2Ddouble(qcross);

  return 1;
}

int Conditional_proba_csomebycsome(real *inb, real *aa, markmap *map, int **y, int nmarker, real **q, real ***qq) {
  /* Forward & Backward Baum algorithm with (inb,aa) different for each chromosome*/
  int i,s,l;
  real prior,proba,trans,p=0.,sum=0.,lsum1=0.;
  real **qstar,**qcross;
  real chr_inb, chr_aa;
  real testsum;


  if ((qstar=Init2Ddouble(nmarker,TOT_IBD_STATE,0))==NULL) { 
    Eprintf("Could not allocate memory for qstar in Conditional_proba\n"); 
    return 0;
  }
  if ((qcross=Init2Ddouble(nmarker,TOT_IBD_STATE,0))==NULL) { 
    Eprintf("Could not allocate memory for qcross in Conditional_proba\n"); 
    return 0;
  }
  /* get qstar & qcross going FORWARD */
  /* Start with first locus: */
  chr_inb=inb[(map[0].chr)];
  chr_aa=aa[(map[0].chr)];
  for (s=0;s<TOT_IBD_STATE;s++) {
    if (!get_prior(s,chr_inb,&prior)) {
      Eprintf("Problem in Conditional_proba_csomebycsome for get_prior at pos 0\n"); 
      return 0;
    }
    if(!get_proba(y[0],s,map[0].freq,&proba)) {
      Eprintf("Problem in Conditional_proba_csomebycsome for get_proba at pos 0\n"); 
      return 0;
    }
    qcross[0][s]=proba*prior;
    qstar[0][s]=prior;
    sum+=qcross[0][s];
  }
  testsum=0;
  for (s=0;s<TOT_IBD_STATE-1;s++) {
    qcross[0][s]/=(real)sum; /* P(I_0|Y_0) normalized */
    testsum+=qcross[0][s];
  }
  qcross[0][TOT_IBD_STATE-1]=1.-testsum;/* P(I_0|Y_0) normalized for TOT_IBD_STATE-1 */
  /* Then loci 1 to L: */
  for (l=1;l<nmarker;l++) {
    lsum1+=log(sum);
    sum=0;
    for (s=0;s<TOT_IBD_STATE;s++) {
      if (!get_proba(y[l],s,map[l].freq,&proba)) { 
	Eprintf("Problem in Conditional_proba_csomebycsome for get_proba\n"); 
	return 0; 
      }
/*       if (map[l].dist==0.0 && map[l-1].dist != 0.0) { */
      if (map[l].chr != map[l-1].chr) {
	/* from now on, use (inb,aa) of chromosome "map[l].chr" */
	/* i.e., if "map[l-1].chr" was chr 1, use now chr 2 */
	chr_inb=inb[(map[l].chr)];
	chr_aa=aa[(map[l].chr)];
	if (!get_prior(s,chr_inb,&trans)) { 
	  Eprintf("Problem in Conditional_proba_csomebycsome for prior at pos=%d, IBD state=%d\n",l,s); 
	  return 0; 
	}
	p=trans;
      } else {
	p=0;
	for (i=0;i<TOT_IBD_STATE;i++) {
	  if (!get_trans(i,s,chr_inb,chr_aa,map[l].dist-map[l-1].dist,&trans)) { 
	    Eprintf("Problem in Conditional_proba_csomebycsome for get_trans\n"); 
	    return 0; 
	  }
	  p+=trans*qcross[l-1][i];
	}
      }
      qstar[l][s]=p;
      qcross[l][s]=p*proba;
      sum+=qcross[l][s];      
    }
      testsum=0;
      for (s=0;s<TOT_IBD_STATE-1;s++) {
	qcross[l][s]/=(real)sum; /* P(I_l|Y_0...Y_l) normalized */
	testsum+=qcross[l][s];
	if (l==nmarker-1) {
	  q[l][s]=qcross[l][s]; /* Last locus P(I_L|Y_all) */
	}
	qcross[l][TOT_IBD_STATE-1]=1.-testsum; /* P(I_l|Y_0...Y_l) normalized for TOT_IBD_STATE-1 */
	if (l==nmarker-1) {
	  q[l][TOT_IBD_STATE-1]=qcross[l][TOT_IBD_STATE-1]; /* Last locus P(I_L|Y_all) */
	}
      }
  }
  
  /* get q going BACKWARD */
  /* Then loci L-1 to 0: */
  chr_inb=inb[(map[nmarker-1].chr)];
  chr_aa=aa[(map[nmarker-1].chr)];
  for (l=nmarker-1;l>0;l--) {
    for (s=0;s<TOT_IBD_STATE;s++) {
/*       if (map[l].dist==0.0 && map[l-1].dist != 0.0) { */
      if (map[l].chr != map[l-1].chr) {
	/* from now on, use (inb,aa) of chromosome "map[l-1].chr" */
	/* i.e., if "map[l].chr" was chr 22, use now chr 21 */
	chr_inb=inb[(map[l-1].chr)]; 
	chr_aa=aa[(map[l-1].chr)];
	q[l-1][s]=qcross[l-1][s];
	for (i=0;i<TOT_IBD_STATE;i++) {
	  qq[l][s][i]=qcross[l-1][s]*q[l][i];
	}
      } else {	
	p=0;
	for (i=0;i<TOT_IBD_STATE;i++) {
	  if (!get_trans(s,i,chr_inb,chr_aa,map[l].dist-map[l-1].dist,&trans)) {
	    Eprintf("Problem in get_trans from Conditional_proba_csomebycsome\n"); 
	    return 0;
	  }
	  if(qstar[l][i]==0) {
	    Eprintf("\nError in Conditional_proba_csomebycsome: qstar[%d][%d]=0, division by zero\n",l,i); 
	    return 0;
	  }
	  p+=trans*q[l][i]/(real)qstar[l][i];
	  qq[l][s][i]=qcross[l-1][s]*trans*q[l][i]/(real)qstar[l][i]; 
	}
	q[l-1][s]=qcross[l-1][s]*p;
      }
    }
  }

  /* Finally, taking care of QQ[0] which is supposed to be P(I_{-1} I_0 |Y_all) */
  for (s=0; s<TOT_IBD_STATE;s++) {
    for (i=0;i<TOT_IBD_STATE;i++) {
      qq[0][i][s]=q[0][s];
    }
  }

  Free2Ddouble(qstar);
  Free2Ddouble(qcross);

  return 1;
}

int Sample_from_posterior1(real **q, real ***qq, int nmarker, int *ibd_sample) {
  /* Sample from X from P(X|Y) using Q & QQ, Thompson (2000) p95 */
  int l;
  real r;

  /* Going backward */
  /* Last locus (L) to start with: */
  r=rans();
/*   r=rand()/(real)RAND_MAX; */
/*   Eprintf("rans=%f\n",r); */
  if(r <= q[nmarker-1][0]) {
    ibd_sample[nmarker-1]=0;
  } else {
    ibd_sample[nmarker-1]=1;
  }

  /* Then loci L-1 to 0: */
  for (l=nmarker-1;l>0;l--) {
    r=rans();
/*     r=rand()/(real)RAND_MAX;     */
/*     Eprintf("rans=%f\n",r); */
    if(r <= qq[l][0][ibd_sample[l]]/q[l][ibd_sample[l]]) {
      ibd_sample[l-1]=0;
    } else {
      ibd_sample[l-1]=1;
    }    
  }

  return 1;
}

/* Begin: 2 genes */
int get_prior(int s, real inb, real *prior) {
  switch (s) {
  case 1:
    *prior=inb;
    break;
  case 0:
    *prior=1-inb;
    break;
  default: 
    Eprintf("Incorrect IBD state %d in get_prior\n",s);
    return 0;
    break;
    }
  return 1;
}

int get_trans(int s1, int s2, real inb, real aa, double x, real *trans) {
  /* s1= IBD state at locus l */
  /* s2= IBD state at locus l+1 */
  /* x= distance in cM between l & l+1 */ 
  switch (s1) {
  case 1:
    if (s2 == 1) {*trans=inb+(1-inb)*exp(-(real)aa*x);}
    else {*trans=(1-inb)*(1-exp(-(real)aa*x));}
    break;
  case 0:
    if (s2 == 1) {*trans=inb*(1-exp(-(real)aa*x));}
    else {*trans=1-inb*(1-exp(-(real)aa*x));}
    break;
  default: 
    Eprintf("Incorrect transition %d in get_trans\n",s1);
    return 0;
    break;
    }

  return 1;  
}

int get_proba(int *yl, int s, double *freq, real *proba) {
  /* HET=1 => use marker heterozygosity */
  /* HET=0 => use (original to FEstim) marker allele frequencies */
  real r;

  if (HET) {
    r=freq[0]; /* homozygosity */
    switch (s) {
    case 1:
      if (yl[0] == yl[1] && yl[0]!=0) {*proba=(1.-EPSILON)+EPSILON*r;}
      else if (yl[0] != yl[1] && yl[0]!=0 && yl[1]!=0) {*proba=EPSILON*(1.-r);}
      /*Auton et al (2009) */
/*       if (yl[0] == yl[1] && yl[0]!=0) {*proba=(1.-EPSILON);} */
/*       else if (yl[0] != yl[1] && yl[0]!=0 && yl[1]!=0) {*proba=EPSILON;} */
      else {*proba=1;}
      break;
    case 0:
      if (yl[0] == yl[1] && yl[0]!=0) {*proba=r;}
      else  if (yl[0] != yl[1] && yl[0]!=0 && yl[1]!=0) {*proba=1.-r;}
      /*Auton et al (2009) */
/*       if (yl[0] == yl[1] && yl[0]!=0) {*proba=r;} */
/*       else  if (yl[0] != yl[1] && yl[0]!=0 && yl[1]!=0) {*proba=1.-r;} */
      else {*proba=1;}
      break;
    default: 
      Eprintf("Incorrect IBD state %d in get_proba\n",s);
      return 0;
      break;
    }
  } else {
    switch (s) {
    case 1:
      if (yl[0] == yl[1] && yl[0]!=0) {*proba=(1-EPSILON)*freq[yl[0]]+EPSILON*pow(freq[yl[0]],2);}
      else if (yl[0] != yl[1] && yl[0]!=0 && yl[1]!=0) {*proba=EPSILON*2*freq[yl[0]]*freq[yl[1]];}
      else {*proba=1;}
      break;
    case 0:
      if (yl[0] == yl[1] && yl[0]!=0) {*proba=pow(freq[yl[0]],2);}
      else  if (yl[0] != yl[1] && yl[0]!=0 && yl[1]!=0) {*proba=2*freq[yl[0]]*freq[yl[1]];}
      else {*proba=1;}
      break;
    default: 
      Eprintf("Incorrect IBD state %d in get_proba\n",s);
      return 0;
      break;
    }
  }
  return 1; 
}

/* int get_proba(int *yl, int s, double *freq, real *proba) { */
/*   switch (s) { */
/*   case 1: */
/*     if (yl[0] == yl[1] && yl[0]!=0) {*proba=(1-EPSILON)*freq[yl[0]]+EPSILON*pow(freq[yl[0]],2);} */
/*     else if (yl[0] != yl[1] && yl[0]!=0 && yl[1]!=0) {*proba=EPSILON*2*freq[yl[0]]*freq[yl[1]];} */
/*     else {*proba=1;} */
/*     break; */
/*   case 0: */
/*     if (yl[0] == yl[1] && yl[0]!=0) {*proba=pow(freq[yl[0]],2);} */
/*     else  if (yl[0] != yl[1] && yl[0]!=0 && yl[1]!=0) {*proba=2*freq[yl[0]]*freq[yl[1]];} */
/*     else {*proba=1;} */
/*     break; */
/*   default:  */
/*     Eprintf("Incorrect IBD state %d in get_proba\n",s); */
/*     return 0; */
/*     break; */
/*     } */
/*   return 1;  */
/* } */

/* End: 2 genes */

