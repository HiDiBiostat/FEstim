/*****************************************************************/
/*      Compute Genomically Controlled Homozygosity Mapping      */
/*                       Lodscore  (FLOD)                        */
/*                     [Apr 2003] [Feb 2006] [July 2006]         */
/*****************************************************************/

 
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "pg.h"
/* #include "rans_al.h" */

/* extern */
int TOT_NUM_LOCUS;
int TOT_NUM_INDIV;
int TOT_NUM_FAM;
int TOT_NUM_ISO;
int NUM_SCALE;
int FIRST_PRINT_CPROBA;
/* int nIndiv; */

int GClogLikRatio(real inb, real **q, real *logTkn) {
  /* Compute loglikelihood ratio for a given individual: */
  /* (f,a) and marker map characteristics                */
  int l;

  for (l=0;l<TOT_NUM_LOCUS;l++) {
    logTkn[l]=(real)(log((double)(q[l][1]+fD*q[l][0]))/log(10.)-log((double)(inb+fD*(1.-inb)))/log(10.));
  }
  
  return 1;
}


int compare( real *f1, real *f2 )
/*-----------------------------------------------------------*/
/* PURPOSE: compare two "real" values */
/*-----------------------------------------------------------*/
{
   if (*f1 < *f2)
      return( -1 );
   else if (*f1 > *f2)
      return( 1 );
   return( 0 );
}

real getmedian( real *data, int   n )
/*-----------------------------------------------------------*/
/* PURPOSE: Return the median of numbers in 'data'.          */
/*-----------------------------------------------------------*/
{
   qsort( data, n, sizeof(real), (int(*)())compare );   
   if (n%2)                                /* 'n' odd */
      return( data[(n+1)/2-1] );
   return( 0.5 * (data[n/2-1] + data[n/2]) );
}

int get_FnA_forLODnuclear(real *inball, real *aall, 
			  int nindiv, real *medF, real *medA) {  

  *medF=getmedian(inball,nindiv);
  *medA=getmedian(aall,nindiv);

  return 1;
}

int GClogLikRatio_nuclear_sample (real *inb, real *a, real *lod_noinbreed, 
				  int *list_affected_indiv, real *medF, 
				  real *medA, real *lTk) {
  real ***qq, **q;
  real *lTkn;
  real *inbfam, *afam;
  char *family;
  int i, parentexist=0, fam=0;
  int found_affected=0, fam_indiv_affected=-1;
  int id, l, nindiv_start, id_prev;
  real mF, mA;

/*   for id = 0 */
  id=0; nindiv_start=id;
  family=(char *) calloc(MAX_LENGTH_FAMID,sizeof(char));
  if (family==NULL) return 0;
  strcpy(family,DATA[id].famid);
  parentexist=0; i=0;
  if ((inbfam=(real *) calloc(MAX_NUM_SIB_FAM,sizeof(real)))==NULL) {    
   Eprintf("\nCould not allocate memory for INDall in GClogLikRatio_nuclear_sample\n"); 
    return 0;
  }
  if ((afam=(real *) calloc(MAX_NUM_SIB_FAM,sizeof(real)))==NULL) {    
   Eprintf("\nCould not allocate memory for INDall in GClogLikRatio_nuclear_sample\n"); 
    return 0;
  }
  /*ALL 2010*/
  /* Take care of the current id */ 
    if(strcmp(DATA[id].dadid,"0")==0 
       && strcmp(DATA[id].momid,"0")==0) {
      if (parentexist<2) {
	parentexist++;
      } else {
	Eprintf("More than 2 founders in family %s\n",DATA[id].famid); 
	return 0;
      }
    } else {
      if (DATAisZERO[id]<TOT_NUM_LOCUS) {
	inbfam[i]=inb[id]; 
	afam[i]=a[id];
	i++;
	if (DATA[id].trait==2 && !found_affected) {
	  fam_indiv_affected=id;
	  found_affected=1;
	}
      }
    }

/*   for 0 < id < TOT_NUM_INDIV */
  for (id=1; id<TOT_NUM_INDIV; id++) {
    if (strcmp(family,DATA[id].famid)!=0) {
      /*different family from id-1 => 1)compute lod, 2)start new family*/
      if ((q=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
	Eprintf("Could not allocate/initialize memory for q in GClogLikRatio_nuclear_sample\n"); 
	return 0;
      }
      if ((qq=Init3Ddouble(TOT_NUM_LOCUS,
		       TOT_IBD_STATE,TOT_IBD_STATE,0))==NULL) { 
	Eprintf("Could not allocate/initialize memory for qq in GClogLikRatio_nuclear_sample\n"); 
	return 0;
      }
      if ((lTkn=(real *) calloc(TOT_NUM_LOCUS,sizeof(real)))==NULL) {    
	Eprintf("\nCould not allocate memory for lTkn in GClogLikRatio_nuclear_sample\n"); 
	return 0;
      }
      for (l=0;l<TOT_NUM_LOCUS;l++) {
	lTkn[l]=0;      
      }

      /* 1) compute lod */
      if (i==0) { /* isolated individual, i.e. no siblings or parents */
	id_prev=id-1;
	if (DATAisZERO[id_prev]==TOT_NUM_LOCUS) {
	  free(family);
	  family=(char *) calloc(MAX_LENGTH_FAMID,sizeof(char));
	  if (family==NULL) return 0;
	  memcpy(family,DATA[id].famid,MAX_LENGTH_FAMID);
	  continue;
	}
	if(!Conditional_proba(inb[id_prev],a[id_prev],MAP,
			      DATA[id_prev].markdat,
			      TOT_NUM_LOCUS,q,qq)) {
	 Eprintf("\nProblem in Conditional_proba for \"nuclear\"\n"); 
	  return 0;
	}
	if(!GClogLikRatio(inb[id_prev],q,lTkn)) {
	 Eprintf("\nProblem in GClogLikRatio in GClogLikRatio_nuclear_sample\n");
	  return 0;
	}
      } else { /* nuclear family, i.e. siblings or parents */
	if (!parentexist) {
	 Eprintf("\nProblem: no parents found for family %s\n",
		 family); 
	  return 0;
	}
	if (!found_affected) {
	 Eprintf("\nProblem: no affected individual in the sibship for family %s\n",
		 family); 
	  return 0;
	}
	if (!get_FnA_forLODnuclear(inbfam, afam, i, &mF, &mA)) {
	 Eprintf("\nProblem in get_FnA_forLODnuclear in GClogLikRatio_nuclear_sample\n");
	  return 0;
	}
	if(fam>TOT_NUM_FAM-1) {
	 Eprintf("\nProblem: more nuclear families found (%d) than expected (%d)\n",
		 fam+1,TOT_NUM_FAM);
	  return 0;
	}
	medF[fam]=mF; medA[fam]=mA;
	if(!Conditional_proba(medF[fam],medA[fam],MAP,
			      DATA[fam_indiv_affected].markdat,
			      TOT_NUM_LOCUS,q,qq)) {
	 Eprintf("\nProblem in Conditional_proba for \"nuclear\"\n"); 
	  return 0;
	}
	if (!GClogLikRatio(medF[fam], q, lTkn)) {
	 Eprintf("\nProblem in GClogLikRatio for \"nuclear\"\n");
	  return 0;
	}
	printf("\nFLOD for family %s: individual %s with (%5.3f,%5.3f) used\n",
	       DATA[fam_indiv_affected].famid,DATA[fam_indiv_affected].id,
	       medF[fam],medA[fam]);
	list_affected_indiv[fam]=fam_indiv_affected;
	fam++;
      }
      for (l=0;l<TOT_NUM_LOCUS;l++) {
	if (lTkn[l]==mINF || lTk[l]==mINF) {
	  lTk[l]=mINF;
	} else {
	  lTk[l]+=lTkn[l];
	}
      }
      free(lTkn);
      Free2Ddouble(q);
      Free3Ddouble(qq,TOT_NUM_LOCUS);
      free(family);
      free(inbfam);
      free(afam);
      /* 2) Start a new family */
      family=(char *) calloc(MAX_LENGTH_FAMID,sizeof(char));
      if (family==NULL) return 0;
      memcpy(family,DATA[id].famid,MAX_LENGTH_FAMID);
      parentexist=0; i=0; found_affected=0; fam_indiv_affected=0;
      if ((inbfam=(real *) calloc(MAX_NUM_SIB_FAM,sizeof(real)))==NULL) {    
	Eprintf("\nCould not allocate memory for INDall in GClogLikRatio_nuclear_sample\n"); 
	return 0;
      }
      if ((afam=(real *) calloc(MAX_NUM_SIB_FAM,sizeof(real)))==NULL) {    
	Eprintf("\nCould not allocate memory for INDall in GClogLikRatio_nuclear_sample\n"); 
	return 0;
      }
    }
    /* Take care of the current id *//*ALL 2010*/
    if(strcmp(DATA[id].dadid,"0")==0 
       && strcmp(DATA[id].momid,"0")==0) {
      if (parentexist<2) {
	parentexist++;
      } else {
	Eprintf("More than 2 founders in family %s\n",DATA[id].famid); 
	return 0;
      }
    } else {
      if (DATAisZERO[id]<TOT_NUM_LOCUS) {
	inbfam[i]=inb[id]; 
	afam[i]=a[id];
	i++;
	if (DATA[id].trait==2 && !found_affected) {
	  fam_indiv_affected=id;
	  found_affected=1;
	}
      }
    }
  }
  if (TOT_NUM_FAM==1 || id==TOT_NUM_INDIV) {  /*ALL 2010*/
    /* To finish up the FLOD computation */
    if ((q=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
     Eprintf("Could not allocate/initialize memory for q in GClogLikRatio_nuclear_sample\n"); 
      return 0;
    }
    if ((qq=Init3Ddouble(TOT_NUM_LOCUS,
			 TOT_IBD_STATE,TOT_IBD_STATE,0))==NULL) { 
     Eprintf("Could not allocate/initialize memory for qq in GClogLikRatio_nuclear_sample\n"); 
      return 0;
    }
    if ((lTkn=(real *) calloc(TOT_NUM_LOCUS,sizeof(real)))==NULL) {    
     Eprintf("\nCould not allocate memory for lTkn in GClogLikRatio_nuclear_sample\n"); 
      return 0;
    }
    for (l=0;l<TOT_NUM_LOCUS;l++) {
      lTkn[l]=0;      
    }

    if (i==0) { /* isolated individual , i.e. no siblings or parents */
      id_prev=id-1;
      if (DATAisZERO[id_prev]<TOT_NUM_LOCUS) {
	if(!Conditional_proba(inb[id_prev],a[id_prev],MAP,
			      DATA[id_prev].markdat,
			      TOT_NUM_LOCUS,q,qq)) {
	  Eprintf("\nProblem in Conditional_proba for \"nuclear\"\n"); 
	  return 0;
	}
	if(!GClogLikRatio(inb[id_prev],q,lTkn)) {
	  Eprintf("\nProblem in GClogLikRatio in GClogLikRatio_nuclear_sample\n");
	  return 0;
	}
      }
    } else { /* nuclear family, i.e. siblings or parents */
      if (!parentexist) {
	Eprintf("\nProblem: no parents found for family %s\n",
		family); 
	return 0;
      }
      if (!found_affected) {
	Eprintf("\nProblem: no affected individual in the sibship for family %s\n",
	       family); 
	return 0;
      }
      if (!get_FnA_forLODnuclear(inbfam, afam, i, &mF, &mA)) {
	Eprintf("\nProblem in get_FnA_forLODnuclear in GClogLikRatio_nuclear_sample\n");
	return 0;
      }
      if(fam>TOT_NUM_FAM-1) {
	Eprintf("\nProblem: more nuclear families found (%d) than expected (%d)\n",
	       fam+1,TOT_NUM_FAM);
	return 0;
      }
      medF[fam]=mF; medA[fam]=mA;
      if(!Conditional_proba(medF[fam],medA[fam],MAP,
			    DATA[fam_indiv_affected].markdat,
			    TOT_NUM_LOCUS,q,qq)) {
	Eprintf("\nProblem in Conditional_proba for \"nuclear\"\n"); 
	return 0;
      }
      if (!GClogLikRatio(medF[fam], q, lTkn)) {
	Eprintf("\nProblem in GClogLikRatio for \"nuclear\"\n");
	return 0;
      }
      printf("\nFLOD for family %s: individual %s with (%5.3f,%5.3f) used\n",
	     DATA[fam_indiv_affected].famid,DATA[fam_indiv_affected].id,
	     medF[fam],medA[fam]);
      list_affected_indiv[fam]=fam_indiv_affected;
    }
    for (l=0;l<TOT_NUM_LOCUS;l++) {
      if (lTkn[l]==mINF || lTk[l]==mINF) {
	lTk[l]=mINF;
      } else {
	lTk[l]+=lTkn[l];
      }
    }
    free(lTkn);
    Free2Ddouble(q);
    Free3Ddouble(qq,TOT_NUM_LOCUS);
    free(family);
    free(inbfam);
    free(afam);
  } else {  /*ALL 2010*/
    Eprintf("\nProblem in GClogLikRatio_nuclear_sample: cannot finish up FLOD computation\n");
    return 0;
  }

  for (l=0;l<TOT_NUM_LOCUS;l++) {
    if (lod_noinbreed[l]==mINF || lTk[l]==mINF) {
      lTk[l]=mINF;
    } else {
      lTk[l]+=lod_noinbreed[l];  
    }    
  } 
    
  return 1;
}

int GClogLikRatio_nuclear_family (real *inb, real *a, 
				  real **fam_lod_noinbreed, 
				  int *list_affected_indiv, real *medF, 
				  real *medA, real *lTk) {
  real ***qq, **q;
  real *lTkn;
  real *inbfam, *afam;
  char *family;
  int i, parentexist=0, fam=0;
  int found_affected=0, fam_indiv_affected=-1;
  int id, l, nindiv_start, id_prev;
  real mF, mA;
  int first_print=0;

/* Initialisation ( for id = 0 ) */
  id=0; nindiv_start=id;
  family=(char *) calloc(MAX_LENGTH_FAMID,sizeof(char));
  if (family==NULL) return 0;
  strcpy(family,DATA[id].famid);
  parentexist=0; i=0;
  if ((inbfam=(real *) calloc(MAX_NUM_SIB_FAM,sizeof(real)))==NULL) {    
   Eprintf("\nCould not allocate memory for INDall in GClogLikRatio_nuclear_family\n"); 
    return 0;
  }
  if ((afam=(real *) calloc(MAX_NUM_SIB_FAM,sizeof(real)))==NULL) {    
   Eprintf("\nCould not allocate memory for INDall in GClogLikRatio_nuclear_family\n"); 
    return 0;
  }
  /*ALL 2010*/
  /* Take care of the current id */ 
  if (strcmp(DATA[id].dadid,"0")==0 
      && strcmp(DATA[id].momid,"0")==0) {
    if (parentexist<2) {
      parentexist++; 
    } else {
      Eprintf("More than 2 founders in family %s\n",DATA[id].famid); 
      return 0;
    }
  } else {
    if (DATAisZERO[id]<TOT_NUM_LOCUS) {
      inbfam[i]=inb[id]; 
      afam[i]=a[id];
      i++;
      if (DATA[id].trait==2 && !found_affected) {
	fam_indiv_affected=id;
	found_affected=1;
      }
    }
  }

/*   for 0 < id < TOT_NUM_INDIV */
  for (id=1; id<TOT_NUM_INDIV; id++) {
    if (strcmp(family,DATA[id].famid)!=0) {
      /*different family from id-1 => 1)compute lod, 2)start new family*/
      if ((q=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
	Eprintf("Could not allocate/initialize memory for q in GClogLikRatio_nuclear_family\n"); 
	return 0;
      }
      if ((qq=Init3Ddouble(TOT_NUM_LOCUS,
		       TOT_IBD_STATE,TOT_IBD_STATE,0))==NULL) { 
	Eprintf("Could not allocate/initialize memory for qq in GClogLikRatio_nuclear_family\n"); 
	return 0;
      }
      if ((lTkn=(real *) calloc(TOT_NUM_LOCUS,sizeof(real)))==NULL) {    
	Eprintf("\nCould not allocate memory for lTkn in GClogLikRatio_nuclear_family\n"); 
	return 0;
      }
      for (l=0;l<TOT_NUM_LOCUS;l++) {
	lTkn[l]=0;      
      }

      /* 1) compute lod */
      if (i==0) { /* isolated individual, i.e. no siblings or parents */
	id_prev=id-1;
	if (DATAisZERO[id_prev]==TOT_NUM_LOCUS) {
	  free(family);
	  family=(char *) calloc(MAX_LENGTH_FAMID,sizeof(char));
	  if (family==NULL) return 0;
	  memcpy(family,DATA[id].famid,MAX_LENGTH_FAMID);
	  continue;	  
	}
	if(!Conditional_proba(inb[id_prev],a[id_prev],MAP,
			      DATA[id_prev].markdat,
			      TOT_NUM_LOCUS,q,qq)) {
	 Eprintf("\nProblem in Conditional_proba for \"nuclear\"\n"); 
	  return 0;
	}
	if(!GClogLikRatio(inb[id_prev],q,lTkn)) {
	 Eprintf("\nProblem in GClogLikRatio in GClogLikRatio_nuclear_family\n");
	  return 0;
	}
	if(!SumNprint_family_lod("family_lodscore.out",fam_lod_noinbreed,
				 0,first_print,fam,id_prev,lTkn)) {
	 Eprintf("\nProblem in Print_family_lod in GClogLikRatio_nuclear_family\n");
	  return 0;
	}
	first_print++;
      } else { /* nuclear family, i.e. siblings or parents */
	if (!parentexist) {
	 Eprintf("\nProblem: no parents found for family %s\n",
		 family); 
	  return 0;
	}
	if (!found_affected) {
	 Eprintf("\nProblem: no affected individual in the sibship for family %s\n",
		 family); 
	  return 0;
	}
	if (!get_FnA_forLODnuclear(inbfam, afam, i, &mF, &mA)) {
	 Eprintf("\nProblem in get_FnA_forLODnuclear in GClogLikRatio_nuclear_family\n");
	  return 0;
	}
	if(fam>TOT_NUM_FAM-1) {
	 Eprintf("\nProblem: more nuclear families found (%d) than expected (%d)\n",
		 fam+1,TOT_NUM_FAM);
	  return 0;
	}
	medF[fam]=mF; medA[fam]=mA;
	if(!Conditional_proba(medF[fam],medA[fam],MAP,
			      DATA[fam_indiv_affected].markdat,
			      TOT_NUM_LOCUS,q,qq)) {
	 Eprintf("\nProblem in Conditional_proba for \"nuclear\"\n"); 
	  return 0;
	}
	if (!GClogLikRatio(medF[fam], q, lTkn)) {
	 Eprintf("\nProblem in GClogLikRatio for \"nuclear\"\n");
	  return 0;
	}
	printf("\nFLOD for family %s: individual %s with (%5.3f,%5.3f) used\n",
	       DATA[fam_indiv_affected].famid,DATA[fam_indiv_affected].id,
	       medF[fam],medA[fam]);
	if(!SumNprint_family_lod("family_lodscore.out",fam_lod_noinbreed,
				 1,first_print,fam,id-1,lTkn)) {
	 Eprintf("\nProblem in Print_family_lod in GClogLikRatio_nuclear_family\n");
	  return 0;
	}
	first_print++;
	list_affected_indiv[fam]=fam_indiv_affected;
	fam++;
      }
      for (l=0;l<TOT_NUM_LOCUS;l++) {
	if (lTkn[l]==mINF || lTk[l]==mINF) {
	  lTk[l]=mINF;
	} else {
	  lTk[l]+=lTkn[l];
	}
      }
      free(lTkn);
      Free2Ddouble(q);
      Free3Ddouble(qq,TOT_NUM_LOCUS);
      free(family);
      free(inbfam);
      free(afam);
      /* 2) Start a new family */
      family=(char *) calloc(MAX_LENGTH_FAMID,sizeof(char));
      if (family==NULL) return 0;
      memcpy(family,DATA[id].famid,MAX_LENGTH_FAMID);
      parentexist=0; i=0; found_affected=0; fam_indiv_affected=0;
      if ((inbfam=(real *) calloc(MAX_NUM_SIB_FAM,sizeof(real)))==NULL) {    
	Eprintf("\nCould not allocate memory for INDall in GClogLikRatio_nuclear_family\n"); 
	return 0;
      }
      if ((afam=(real *) calloc(MAX_NUM_SIB_FAM,sizeof(real)))==NULL) {    
	Eprintf("\nCould not allocate memory for INDall in GClogLikRatio_nuclear_family\n"); 
	return 0;
      }
    }
    /* Take care of the current id *//*ALL 2010*/
    if (strcmp(DATA[id].dadid,"0")==0 
	&& strcmp(DATA[id].momid,"0")==0) {
      if (parentexist<2) {
	parentexist++; 
      } else {
	Eprintf("More than 2 founders in family %s\n",DATA[id].famid); 
	return 0;
      }
    } else {
      if (DATAisZERO[id]<TOT_NUM_LOCUS) {
	inbfam[i]=inb[id]; 
	afam[i]=a[id];
	i++;
	if (DATA[id].trait==2 && !found_affected) {
	  fam_indiv_affected=id;
	  found_affected=1;
	}
      }
    }
  }
  if (TOT_NUM_FAM==1 || id==TOT_NUM_INDIV) { /*ALL 2010*/
    /* To finish up the FLOD computation */
    if ((q=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
     Eprintf("Could not allocate/initialize memory for q in GClogLikRatio_nuclear_family\n"); 
      return 0;
    }
    if ((qq=Init3Ddouble(TOT_NUM_LOCUS,
			 TOT_IBD_STATE,TOT_IBD_STATE,0))==NULL) { 
     Eprintf("Could not allocate/initialize memory for qq in GClogLikRatio_nuclear_family\n"); 
      return 0;
    }
    if ((lTkn=(real *) calloc(TOT_NUM_LOCUS,sizeof(real)))==NULL) {    
     Eprintf("\nCould not allocate memory for lTkn in GClogLikRatio_nuclear_family\n"); 
      return 0;
    }
    for (l=0;l<TOT_NUM_LOCUS;l++) {
      lTkn[l]=0;      
    }

    if (i==0) { /* isolated individual , i.e. no siblings or parents */
      id_prev=id-1;
      if (DATAisZERO[id_prev]<TOT_NUM_LOCUS) {
	if(!Conditional_proba(inb[id-1],a[id-1],MAP,DATA[id-1].markdat,
			      TOT_NUM_LOCUS,q,qq)) {
	  Eprintf("\nProblem in Conditional_proba for \"nuclear\"\n"); 
	  return 0;
	}
	if(!GClogLikRatio(inb[id-1],q,lTkn)) {
	  Eprintf("\nProblem in GClogLikRatio in GClogLikRatio_nuclear_family\n");
	  return 0;
	}
	if(!SumNprint_family_lod("family_lodscore.out",fam_lod_noinbreed,
				 0,first_print,fam,id-1,lTkn)) {
	  Eprintf("\nProblem in Print_family_lod in GClogLikRatio_nuclear_family\n");
	  return 0;
	}
	first_print++;
      }
    } else { /* nuclear family, i.e. siblings or parents */
      if (!parentexist) {
	Eprintf("\nProblem: no parents found for family %s\n",
		 family); 
	return 0;
      }
      if (!found_affected) {
	Eprintf("\nProblem: no affected individual in the sibship for family %s\n",
	       family); 
	return 0;
      }
      if (!get_FnA_forLODnuclear(inbfam, afam, i, &mF, &mA)) {
	Eprintf("\nProblem in get_FnA_forLODnuclear in \n");
	return 0;
      }
      if(fam>TOT_NUM_FAM-1) {
	Eprintf("\nProblem: more nuclear families found (%d) than expected (%d)\n",
	       fam+1,TOT_NUM_FAM);
	return 0;
      }
      medF[fam]=mF; medA[fam]=mA;
      if(!Conditional_proba(medF[fam],medA[fam],MAP,
			    DATA[fam_indiv_affected].markdat,
			    TOT_NUM_LOCUS,q,qq)) {
	Eprintf("\nProblem in Conditional_proba for \"nuclear\"\n"); 
	return 0;
      }
      if (!GClogLikRatio(medF[fam], q, lTkn)) {
	Eprintf("\nProblem in GClogLikRatio for \"nuclear\"\n");
	return 0;
      }
      printf("\nFLOD for family %s: individual %s with (%5.3f,%5.3f) used\n",
	     DATA[fam_indiv_affected].famid,DATA[fam_indiv_affected].id,
	     medF[fam],medA[fam]);
      if(!SumNprint_family_lod("family_lodscore.out",fam_lod_noinbreed,
			       1,first_print,fam,id-1,lTkn)) {
	Eprintf("\nProblem in Print_family_lod in GClogLikRatio_nuclear_family\n");
	return 0;
      }
      first_print++;
      list_affected_indiv[fam]=fam_indiv_affected;    
    }

    for (l=0;l<TOT_NUM_LOCUS;l++) {
      if (lTkn[l]==mINF || lTk[l]==mINF) {
	lTk[l]=mINF;
      } else {
	lTk[l]+=lTkn[l];
      }
    }
    free(lTkn);
    Free2Ddouble(q);
    Free3Ddouble(qq,TOT_NUM_LOCUS);
    free(family);
    free(inbfam);
    free(afam);
  } else {  /*ALL 2010*/
    Eprintf("\nProblem in GClogLikRatio_nuclear_family: cannot finish up FLOD computation\n");
    return 0;
  }

  return 1;
}
